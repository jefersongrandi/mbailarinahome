<template>
  <div>
    <router-link to="/">
      Home
    </router-link> | <router-link to="/medium">
      Medium
    </router-link>
    <router-view />
  </div>
</template>
