<template>
  <h1>Home Page</h1>
</template>

<script>
export default {
    name: 'AppHome'
};
</script>

<style scoped>
    h1  {
        color: green;
    }
</style>