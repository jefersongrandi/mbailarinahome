<template>
  <div class="title">
    <h1>Medium Page</h1>
  </div>
</template>

<script>
export default {
    name: 'AppMedium'
};
</script>

<style lang="scss" scoped>
    .title {
        h1 {
            color: red;
        }
    }
</style>